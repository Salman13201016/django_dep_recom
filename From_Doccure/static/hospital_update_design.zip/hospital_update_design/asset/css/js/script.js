// Hospital list search bar icon view
// $(".h_search_bar").focus(function () {
//   console.log($("#h_top_search_icon"));
//   $("#h_top_search_icon").classList.toggle("display_block");
// });

// let search_bar = document.querySelector(".h_search_bar");
// console.log(search_bar)
// search_bar.addEventListener('focus', function(){
//     let search_icon = document.getElementById("#h_top_search_icon");
//     search_icon.classList.add("display_block");
// })
