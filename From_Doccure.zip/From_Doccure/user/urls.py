# from django.contrib import admin
# from django.urls import path
# from . import views as user
# from django.contrib.auth import views as auth_views


# urlpatterns = [  
#     path('', user.index_panel,name='index'),
#     path('alogin/', user.login_panel,name='login'),
#     path('asignup/', user.signup_panel,name='signup'),
#     # path('index_store/', user.index_store,name='index_store'),
#     path('alogout/', auth_views.LogoutView.as_view(next_page='login'),name='logout') 
    
# ]