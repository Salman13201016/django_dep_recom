from django.apps import AppConfig


class HospitalMapConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "hospital_map"
