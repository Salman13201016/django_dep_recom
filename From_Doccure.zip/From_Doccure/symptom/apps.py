from django.apps import AppConfig


class SymptomConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'symptom'
